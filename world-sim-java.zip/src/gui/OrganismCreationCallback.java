package gui;

import simulation.Vector2;

public interface OrganismCreationCallback {
    void create(String name, Vector2 position);
}
