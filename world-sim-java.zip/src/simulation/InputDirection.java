package simulation;

public enum InputDirection {
    NONE, LEFT, RIGHT, UP, DOWN,
}
