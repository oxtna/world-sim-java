package simulation.maps;

public class MapSlotEmptyException extends Exception {
    public MapSlotEmptyException() {
        super();
    }
}
