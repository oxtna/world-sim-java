package simulation.maps;

public class MapSlotNotEmptyException extends Exception {
    public MapSlotNotEmptyException() {
        super();
    }
}
