package simulation.organisms;

public class AnimalNotReproducibleException extends Exception {
    public AnimalNotReproducibleException(String message) {
        super(message);
    }
}
